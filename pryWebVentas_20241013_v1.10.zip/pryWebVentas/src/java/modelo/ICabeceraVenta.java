package modelo;

/**
 *
 * @author gerson
 */
public interface ICabeceraVenta {
          public int registrarCabecera(CabeceraVenta cvent);

}
