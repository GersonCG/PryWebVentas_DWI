
package modelo;

/**
 *
 * @author Cesar
 */

import java.util.List;

public interface IVenta {
    
    public List<Ventas> listarVentas();
    // public Ventas mostrarVenta(int id);
    // public void imprimirVenta(Ventas vent);
    
    // public boolean insertarVenta(Ventas vent);
    // public boolean modificarVenta(Ventas vent);
    // public boolean eliminarVenta(int id);
    
    
}
