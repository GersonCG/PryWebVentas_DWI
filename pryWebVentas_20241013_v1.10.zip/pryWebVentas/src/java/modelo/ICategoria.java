package modelo;
import java.util.List;

public interface ICategoria {
    public List<Categoria> listarCategorias();
    
}
