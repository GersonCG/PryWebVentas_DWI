
package modelo;
import java.util.List;

public interface IFactura {
    public List<Factura> listarFacturas();
    
}
